      integer ad_qmax_
      parameter (ad_qmax_=1)
